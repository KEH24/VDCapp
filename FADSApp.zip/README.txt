APK বানানোর নিয়ম (GitHub, Android Studio ছাড়াই):
1. github.com এ নতুন repository খুলুন।
2. এই ZIP এর সব ফাইল (.github ফোল্ডারসহ) upload করুন।
3. Actions ট্যাব -> "Build APK" চলবে -> শেষে Artifacts থেকে FADS-Engineer-apk ডাউনলোড করুন।
Android Studio তে: এই ফোল্ডারটা Open করে Build > Build APK(s)।
